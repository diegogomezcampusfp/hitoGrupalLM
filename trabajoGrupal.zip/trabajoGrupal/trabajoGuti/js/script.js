//Fetch
function procesarRespuesta (data) {
	let capa = document.getElementById('destino');
	capa.innerHTML = data;
}

function llenarTabla(data) {
    var i;
    var textJson = data;
    var table="<tr><th>Titulo</th><th>Director</th><th>Estreno</th><th>Calificación</th></tr>";
    var obj = JSON.parse(textJson);
    for (i = 0; i <obj.length; i++) { 
        table += "<tr><td>" +
		obj[i].Titulo +
		"</td><td>" +
		obj[i].Director +
		"</td><td>" +
		obj[i].Estreno +
		"</td><td>" +
		obj[i].Calificación +
		"</td><tr>";
            
    }
	
    document.getElementById("demo").innerHTML = table;
}


function peticion(rutaUrl) {
	const options = {
	  method: "GET",
	};
	
	fetch(rutaUrl, options)
  		.then(response => response.text())
  		.then(data => procesarRespuesta(data));
  		
}

function load2() {
	const options = {
	  method: "GET",
	};
	
	fetch("https://api.jsonbin.io/b/629f26e3402a5b38021f1e6d", options)
  		.then(response => response.text())
  		.then(data => llenarTabla(data));
}





